# IziBot
Bot simple para automatizar tareas, consta con acciones simples como escribir, esperar, clic y lectura con OCR.


## Pre-Requisitos
Descargar e instalar [Tesseract OCR](https://github.com/UB-Mannheim/tesseract/wiki)

## Descargas
--onefile  
[Ejecutable único](https://github.com/techeca/iziBot/releases/download/v1.0.0/main.exe)

--onedir  
[Carpeta completa](https://github.com/techeca/iziBot/releases/download/v1.0.0/iziBot.rar)

## Uso
Ejecutar `main.exe` para iniciar  el programa.

Ingresa la acciones que deseas para generar una rutina.


Inicia la rutina. 

### Clic
Realiza un Clic en el lugar especificado.

### Esperar
Espera el tiempo especificado.

### Escribir
Escribe el texto especificado.

## Core
Las funciones principales del core pueden ser reutilizadas en otros proyectos de la siguiente forma:

Instalar
```
```

### Funciones
```
```